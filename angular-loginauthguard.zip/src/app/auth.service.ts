import { Injectable } from '@angular/core';
import {Router} from '@angular/router';
@Injectable()
export class AuthService {

  constructor(private router:Router) { }

setSecureToken(token:string){
localStorage.setItem("LoginId",token);
}

getSecureToken(){
  return localStorage.getItem("LoginId");
}

isLoggedIn(){
  return this.getSecureToken()!==null;
}
logout(){
  localStorage.removeItem("LoginId");
  this.router.navigate(['login']);
}
}