import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
loginform:any={};
username:any;
password:any;
  constructor(private authservice:AuthService,private router:Router) { }

  ngOnInit() {
  }
  login(loginform){
this.username= this.loginform.uname;
this.password= this.loginform.upassword;
console.log(this.username);
console.log(this.password);
this.authservice.setSecureToken(this.username);
this.router.navigate(['home']);
  }

}