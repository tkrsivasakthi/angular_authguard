import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import{Router,RouterModule,Routes} from '@angular/router';
import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AuthService } from './auth.service';
import { HomeComponent } from './home/home.component';
import { AuthGuard } from './auth.guard';
import { NavbarComponent } from './navbar/navbar.component';
const myroute:Routes=[
  {path : '',component:HomeComponent,pathMatch: 'full' ,canActivate: [AuthGuard]},
  {path : 'login',component:LoginComponent},
  {path : 'home',component:HomeComponent, canActivate: [AuthGuard]},
  {path : 'register',component:RegisterComponent,canActivate: [AuthGuard]}
  ]
@NgModule({
  imports:      [ BrowserModule, FormsModule,RouterModule.forRoot(myroute) ],
  declarations: [ AppComponent, HelloComponent, LoginComponent, RegisterComponent, HomeComponent, NavbarComponent ],
  bootstrap:    [ AppComponent ],
  providers: [AuthService,AuthGuard]
})
export class AppModule { }
